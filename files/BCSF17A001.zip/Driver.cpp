#include <iostream>
using namespace std;

int division(int a, int b) {
    return a / b;
}

int main() {
    int a, b;
    cin >> a >> b;
    cout << "Divison: " << a / b << endl;
    return 0;
}
