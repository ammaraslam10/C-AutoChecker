#include <iostream>
using namespace std;

float division(float a, int b) {
    if (b == 0)
        return 0;
    return a / b;
}

int main() {
    int a, b;
    cin >> a >> b;
    cout << "Divison: " << a / b << endl;
    return 0;
}
